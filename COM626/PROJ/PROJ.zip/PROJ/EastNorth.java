
public class EastNorth {
    public double easting,northing;
    
    public EastNorth(double easting, double northing)
    {
        this.easting=easting;
        this.northing=northing;
    }
    
    public String toString()
    {
        return "easting= "+easting+ " northing="+northing;
    }
}    
